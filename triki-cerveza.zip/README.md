# Triki - Cerveza Artesanal Premium

Sitio web para la marca de cerveza artesanal Triki, diseñado para ser elegante, responsivo y fácil de mantener. Está optimizado para su despliegue en Netlify.

## Estructura del Proyecto